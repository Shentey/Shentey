from django.apps import AppConfig


class VistapreviaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'vistaprevia'
