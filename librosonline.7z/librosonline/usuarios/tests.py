from django.test import TestCase
import pytest 

def test_prueba():
    assert 1 == 1
# Create your tests here.
