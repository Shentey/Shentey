from django.contrib import admin
from usuarios.models import Datosusuario
# Register your models here.

admin.site.register(Datosusuario)
